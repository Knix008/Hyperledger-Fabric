// Put common helper classes and functions here.
