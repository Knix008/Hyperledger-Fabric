# Fabric API Tests

This folder contains tests that target Fabric shim API methods that may be called within chaincode

Fabric chaincode may be written in two ways:
- Using a Contract wrapper
- Coding direct to the shim

These methods are split within the contract and base folders respectively.